package com.example.observerzone.mixin;

import com.example.observerzone.ZoneManager;
import net.minecraft.class_2338;
import net.minecraft.class_2426;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2426.class)
public class ObserverBlockMixin {

	/**
	 * 侦测器的计划刻分两步：未充能时的那一刻负责"点亮"，已充能时的那一刻负责"熄灭"。
	 * 只拦截"点亮"这一步：区域内的侦测器不会发出信号，
	 * 而已经处于充能状态的侦测器仍能正常熄灭，不会卡在常亮状态。
	 */
	@Inject(method = "tick", at = @At("HEAD"), cancellable = true)
	private void observerzone$blockActivation(class_2680 state, class_3218 level, class_2338 pos,
											  class_5819 random, CallbackInfo ci) {
		if (!state.method_11654(class_2741.field_12484) && ZoneManager.isDisabled(level, pos)) {
			ci.cancel();
		}
	}
}
