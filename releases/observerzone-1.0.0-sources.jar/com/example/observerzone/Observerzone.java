package com.example.observerzone;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Observerzone implements ModInitializer {
	public static final String MOD_ID = "observerzone";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ServerLifecycleEvents.SERVER_STARTED.register(ZoneManager::load);
		ServerLifecycleEvents.SERVER_STOPPED.register(server -> ZoneManager.unload());

		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(class_2170.method_9247("observerzone")
						// 需要 OP 权限（等级 2）。若这一行编译报错，见回复里的说明
						.requires(class_2170.method_71774(class_2170.field_31839))
						.then(class_2170.method_9247("add")
								.then(class_2170.method_9244("name", StringArgumentType.word())
										.then(class_2170.method_9244("from", class_2262.method_9698())
												.then(class_2170.method_9244("to", class_2262.method_9698())
														.executes(Observerzone::add)))))
						.then(class_2170.method_9247("remove")
								.then(class_2170.method_9244("name", StringArgumentType.word())
										.suggests((ctx, builder) -> {
											ZoneManager.all().forEach(z -> builder.suggest(z.name()));
											return builder.buildFuture();
										})
										.executes(Observerzone::remove)))
						.then(class_2170.method_9247("list").executes(Observerzone::list))));
	}

	private static int add(CommandContext<class_2168> ctx) {
		class_2168 src = ctx.getSource();
		String name = StringArgumentType.getString(ctx, "name");
		class_2338 a = class_2262.method_48299(ctx, "from");
		class_2338 b = class_2262.method_48299(ctx, "to");
		String dim = ZoneManager.dimensionId(src.method_9225());

		ZoneManager.Zone zone = new ZoneManager.Zone(name, dim,
				Math.min(a.method_10263(), b.method_10263()), Math.min(a.method_10264(), b.method_10264()), Math.min(a.method_10260(), b.method_10260()),
				Math.max(a.method_10263(), b.method_10263()), Math.max(a.method_10264(), b.method_10264()), Math.max(a.method_10260(), b.method_10260()));

		if (!ZoneManager.add(zone)) {
			src.method_9213(class_2561.method_43470("已存在同名区域: " + name));
			return 0;
		}
		src.method_9226(() -> class_2561.method_43470("已创建禁用区域 " + describe(zone)), true);
		return 1;
	}

	private static int remove(CommandContext<class_2168> ctx) {
		String name = StringArgumentType.getString(ctx, "name");
		if (ZoneManager.remove(name)) {
			ctx.getSource().method_9226(() -> class_2561.method_43470("已删除区域: " + name), true);
			return 1;
		}
		ctx.getSource().method_9213(class_2561.method_43470("找不到区域: " + name));
		return 0;
	}

	private static int list(CommandContext<class_2168> ctx) {
		var zones = ZoneManager.all();
		if (zones.isEmpty()) {
			ctx.getSource().method_9226(() -> class_2561.method_43470("当前没有禁用区域"), false);
			return 0;
		}
		for (ZoneManager.Zone z : zones) {
			ctx.getSource().method_9226(() -> class_2561.method_43470(describe(z)), false);
		}
		return zones.size();
	}

	private static String describe(ZoneManager.Zone z) {
		return String.format("%s [%s] (%d, %d, %d) ~ (%d, %d, %d)", z.name(), z.dimension(),
				z.minX(), z.minY(), z.minZ(), z.maxX(), z.maxY(), z.maxZ());
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}
